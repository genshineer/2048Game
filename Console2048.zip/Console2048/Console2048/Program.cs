﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Console2048
{
    class Program
    {
        
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            Console.BackgroundColor = ConsoleColor.White;
            Console.Title = "2048 Game(Manmade)";
            Console.SetWindowSize(80, 30);
            GameCore core = new GameCore();
            core.GenerateNumber();
            core.GenerateNumber();

            DrawMap(core.Map);
            for (; ; )
            {
                Act(core);
                if (core.IsChange)
                    core.GenerateNumber();
                if (DrawMap(core.Map)) {
                    GetWin();
                    Console.ReadKey();
                    return;
                }
                if (Lose(core.Map)) {
                    Console.WriteLine("You Lose.");
                    Console.WriteLine("10s后按任意键退出");
                    Thread.Sleep(10000);
                    Console.ReadLine();
                    return;
                }
            }
        }

        private static void GetWin() {
            Console.WriteLine("You Win.");
        }

        private static bool ChangeColour(int val)
        {
            if (val == 0) Console.ForegroundColor = ConsoleColor.Black;
            else if (val == 2) Console.ForegroundColor = ConsoleColor.DarkGray;
            else if (val == 4) Console.ForegroundColor = ConsoleColor.DarkGreen;
            else if (val == 8) Console.ForegroundColor = ConsoleColor.DarkYellow;
            else if (val == 16) Console.ForegroundColor = ConsoleColor.DarkCyan;
            else if (val == 32) Console.ForegroundColor = ConsoleColor.Gray;
            else if (val == 64) Console.ForegroundColor = ConsoleColor.Green;
            else if (val == 128) Console.ForegroundColor = ConsoleColor.Yellow;
            else if (val == 256) Console.ForegroundColor = ConsoleColor.Cyan;
            else if (val == 512) Console.ForegroundColor = ConsoleColor.Blue;
            else if (val == 1024) Console.ForegroundColor = ConsoleColor.DarkMagenta;
            else
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                return true;
            }
            return false;
        }

        private static bool Lose(int[,] map)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (i + 1 < 4) if (map[i, j] == map[i + 1, j]) return false;
                    if (j + 1 < 4) if (map[i, j] == map[i, j + 1]) return false;
                    if (map[i, j] == 0) return false;
                }
            }
            return true;
        }

        private static bool DrawMap(int[,] map)
        {
            Console.Clear();
            bool flag = false;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (ChangeColour(map[i, j])) flag = true;
                    Console.Write(map[i, j] + "\t");
                }
                Console.WriteLine();
            }
            return flag;
        }
        /// <summary>
        /// 键盘事件
        /// </summary>
        /// <param name="bVk"> virtual-key code</param>
        /// <param name="bScan">hardware scan code</param>
        /// <param name="dwFlags"> flags specifying various function options</param>
        /// <param name="dwExtraInfo"> additional data associated with keystroke</param>
        [DllImport("user32.dll")]
        public static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

        [DllImport("user32.dll")]
        private static extern short GetAsyncKeyState(System.Windows.Forms.Keys vKey);

        private static void Act(GameCore core)
        {
loop:
            short a, b, c, d, tmp;
            a = GetAsyncKeyState(System.Windows.Forms.Keys.A);
            b = GetAsyncKeyState(System.Windows.Forms.Keys.W);
            c = GetAsyncKeyState(System.Windows.Forms.Keys.S);
            d = GetAsyncKeyState(System.Windows.Forms.Keys.D);
            if (a < 0) tmp = 1;
            else if (b < 0) tmp = 2;
            else if (c < 0) tmp = 3;
            else if (d < 0) tmp = 4;
            else goto loop;
            switch (tmp)
            {
                case 2:
                    core.Move(Movement.Up);
                    break;
                case 3:
                    core.Move(Movement.Down);
                    break;
                case 1:
                    core.Move(Movement.Left);
                    break;
                case 4:
                    core.Move(Movement.RIght);
                    break;
            }
            Thread.Sleep(150);
        }
    }
}
