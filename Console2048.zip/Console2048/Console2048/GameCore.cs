﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console2048
{
    class GameCore
    {
        private int[,] map;
        private int[] mergeArray;
        int[] removeZeroArray;
        private List<Position> emptyPositionList;
        private Random random;
        private int[,] originalMap;

        public bool IsChange
        {
            get;
            set;
        }

        public int[,] Map
        {
            get { return this.map; }
        }

        public GameCore() {
            map = new int[4, 4];
            mergeArray = new int[4];
            removeZeroArray = new int[4];
            emptyPositionList = new List<Position>(16);
            random = new Random();
            originalMap = new int[4, 4];
        }

        private void RemoveZero()
        {
            Array.Clear(removeZeroArray, 0, 4);
            int index = 0;
            for (int i = 0; i < mergeArray.Length; i++)
            {
                if (mergeArray[i] != 0) removeZeroArray[index++] = mergeArray[i];
            }
            removeZeroArray.CopyTo(mergeArray, 0);
        }

        private void Merge()
        {
            RemoveZero();
            for (int i = 0; i < mergeArray.Length - 1; i++)
            {
                if (mergeArray[i] != 0 && mergeArray[i] == mergeArray[i + 1])
                {
                    mergeArray[i] += mergeArray[i + 1];
                    mergeArray[i + 1] = 0;
                }
            }
            RemoveZero();
        }

        private void MoveUp()
        {
            for (int j = 0; j < map.GetLength(1); j++)
            {
                for (int i = 0; i < map.GetLength(0); i++)
                    mergeArray[i] = map[i, j];
                Merge();
                for (int i = 0; i < map.GetLength(0); i++)
                    map[i, j] = mergeArray[i];
            }
        }

        private void MoveDown()
        {
            for (int j = 0; j < map.GetLength(1); j++)
            {
                for (int i = map.GetLength(0) - 1; i >= 0; i--)
                    mergeArray[3 - i] = map[i, j];
                Merge();
                for (int i = map.GetLength(0) - 1; i >= 0; i--)
                    map[i, j] = mergeArray[3 - i];
            }
        }

        private void MoveLeft()
        {
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                    mergeArray[j] = map[i, j];
                Merge();
                for (int j = 0; j < map.GetLength(1); j++)
                    map[i, j] = mergeArray[j];
            }
        }

        private void MoveRight()
        {
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = map.GetLength(1) - 1; j >= 0; j--)
                    mergeArray[3 - j] = map[i, j];
                Merge();
                for (int j = map.GetLength(1) - 1; j >= 0; j--)
                    map[i, j] = mergeArray[3 - j];
            }
        }

        public void Move(Movement direction)
        {
            Array.Copy(map, originalMap, map.Length);
            IsChange = false;
            switch (direction)
            {
                case Movement.Up:
                    MoveUp();
                    break;
                case Movement.Down:
                    MoveDown();
                    break;
                case Movement.Left:
                    MoveLeft();
                    break;
                case Movement.RIght:
                    MoveRight();
                    break;
            }
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    if (map[i, j] != originalMap[i, j])
                    {
                        IsChange = true;
                        return;
                    }
                }
            }
        }

        private void CalcEmpty()
        {
            emptyPositionList.Clear();
            for (int i = 0; i < map.GetLength(0); i++)
            {
                for (int j = 0; j < map.GetLength(1); j++)
                {
                    if (map[i, j] == 0)
                    {
                        emptyPositionList.Add(new Position(i, j));
                    }
                }
            }
        }

        public void GenerateNumber()
        {
            CalcEmpty();
            if (emptyPositionList.Count > 0)
            {
                int randomIndex = random.Next(0, emptyPositionList.Count);
                Position pos = emptyPositionList[randomIndex];
                map[pos.RIndex, pos.CIndex] = random.Next(0, 10) == 1 ? 4 : 2;
            }
        }
    }
}
