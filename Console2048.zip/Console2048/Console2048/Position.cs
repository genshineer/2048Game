﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console2048
{
    struct Position
    {
        public int RIndex
        {
            get;
            set;
        }

        public int CIndex
        {
            get;
            set;
        }

        public Position(int rIndex, int cIndex)
            : this()
        {
            this.RIndex = rIndex;
            this.CIndex = cIndex;
        }
    }
}
